<a href="{{ route('dashboard') }}">
    <img src="{{ asset('img/logo_umtas.png') }}" style="height: 50px; width: auto;">
</a>
