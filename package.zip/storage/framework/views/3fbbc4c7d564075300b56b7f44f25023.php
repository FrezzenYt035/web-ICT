<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Manajemen Informasi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="img/logo_umtas.png">
    <style>
        /* RESET */
        * {
            margin: 0; padding: 0;
            box-sizing: border-box;
        }
        .bawah {
            font-family: 'Segoe UI', sans-serif;
            background: #f0f2f5;
            padding: 40px 20px;
        }

        .container {
            max-width: 1000px;
            margin: auto;
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
        }

        .card {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            padding: 20px;
            margin-bottom: 10px;
            scale: 0.85;
        }

        .form-group {
            margin-bottom: 16px;
        }

        input[type="text"],
        textarea,
        input[type="file"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 15px;
            background-color: #f9f9f9;
        }

        textarea {
            resize: vertical;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            transition: background 0.3s ease;
        }

        .btn-primary {
            background-color: #4f46e5;
            color: #fff;
        }

        .btn-danger {
            background-color: #dc2626;
            color: #fff;
        }

        .btn-warning {
            background-color: #facc15;
            color: #000;
        }

        .btn + .btn {
            margin-left: 10px;
        }

        .info-list {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }

        .info-card {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.07);
            overflow: hidden;
            width: calc(50% - 10px);
            min-width: 300px;
        }

        .info-card img {
            width: 100%;
            height: 400px;
            object-fit: cover;
        }

        .info-content {
            padding: 16px;
        }

        .info-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 8px;
        }

        .info-desc {
            font-size: 14px;
            color: #555;
            margin-bottom: 12px;
        }

        .info-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            padding: 0 16px 16px;
        }

        .edit-form {
            margin-top: 16px;
            background: #f9fafb;
            padding: 12px;
            border-radius: 8px;
        }

        @media (max-width: 768px) {
            .info-card {
                width: 100%;
            }
        }

        h2 {
      margin-bottom: 30px;
    }

    .info-container {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      justify-content: center;
    }

    .info-card {
      background: white;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      overflow: hidden;
      width: 300px;
    }

    .info-card img {
      width: 100%;
      height: 200px;
      object-fit: cover;
    }

    .info-content {
      padding: 15px;
    }

    .info-title {
      font-size: 18px;
      font-weight: bold;
      margin-bottom: 10px;
    }

    .info-description {
      font-size: 14px;
      color: #555;
      margin-bottom: 15px;
      overflow: hidden;        /* Sembunyikan teks yang kelebihan */
      text-overflow: ellipsis; /* Tambahkan tanda titik-titik (...) */
      display: -webkit-box;
      -webkit-line-clamp: 2;   /* Batas baris, bisa diubah */
      -webkit-box-orient: vertical;
    }

    .button-group {
      display: flex;
      justify-content: space-between;
      
    }

    .btn {
      padding: 8px 12px;
      font-size: 14px;
      border: none;
      border-radius: 4px;
      color: white;
      cursor: pointer;
      text-decoration: none;
    }

    .btn-edit {
      background-color: #ffc107;
    }

    .btn-edit:hover {
      background-color: #e0a800;
    }

    .btn-delete {
      background-color: #dc3545;
    }

    .btn-delete:hover {
      background-color: #c82333;
    }
    .alert {
      padding: 15px;
      margin: 20px 0;
      border-radius: 5px;
      position: relative;
      font-size: 16px;
      line-height: 1.5;
}

.alert-success {
  background-color: #d4edda;
  color: #155724;
  border: 1px solid #c3e6cb;
}

.alert-danger {
  background-color: #f8d7da;
  color: #721c24;
  border: 1px solid #f5c6cb;
}

.alert ul {
  margin: 0;
  padding-left: 20px;
}

.closebtn {
  position: absolute;
  top: 8px;
  right: 16px;
  font-size: 20px;
  cursor: pointer;
  color: inherit;
}

    </style>
</head>
<body>
  <?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Upload Informasi')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="bawah">
        <div class="container">
    <br>
     <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" onclick="this.parentElement.style.display='none';">&times;</button>
                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <button type="button" class="btn-close" onclick="this.parentElement.style.display='none';">&times;</button>
                </div>
            <?php endif; ?>

    <!-- Form Tambah Informasi -->

    <div class="card">
        <h3><?php echo e(isset($informasidetail) ? 'Edit Informasi' : 'Tambah Informasi'); ?></h3>
        <form action="<?php echo e(isset($informasidetail) ? route('admin.informasi.update', ['id' => $informasidetail->id]) : route('admin.informasi.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if(isset($informasidetail)): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>
            <div class="form-group">
                <input type="text" name="judul" placeholder="Judul Informasi" value="<?php echo e(isset($informasidetail) ? $informasidetail->judul : old('judul')); ?>" required>
            </div>
            <div class="form-group">
                <textarea name="deskripsi" rows="10" placeholder="Deskripsi" required><?php echo e(isset($informasidetail) ? $informasidetail->deskripsi : old('deskripsi')); ?></textarea>
            </div>
            <div class="form-group">
                <input type="file" name="gambar" accept="image/*" <?php if(!isset($informasidetail)): ?> required <?php endif; ?>>
            </div>
            <button type="submit" class="btn btn-primary">Simpan Informasi</button>
        </form>
    </div>

   <br>

  <div class="info-container">
    <!-- Card 1 -->
    <?php $__currentLoopData = $informasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="info-card">
      <img src="<?php echo e(asset('uploads/' . $info->gambar)); ?>" alt="<?php echo e($info->judul); ?>"
         style="width:100%; height:200px; object-fit:cover;" />
        <div class="info-content">
        <div class="info-title"><?php echo e($info->judul); ?></div>
        <div class="info-description">
          <?php echo e($info->deskripsi); ?>

        </div>
        <div class="button-group">
          <a href="<?php echo e(route('admin.informasi.edit', ['id' =>$info->id])); ?>" class="btn btn-edit">
              <i class="fas fa-edit"></i>
              Edit
          </a>
          <form action="<?php echo e(route('admin.informasi.delete', ['id' => $info->id])); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus informasi ini?');">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-delete">
              <i class="fas fa-trash-alt"></i>
              Hapus
            </button>
          </form>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <!-- Tambahkan card lainnya jika perlu -->
  </div>
</div>
<script>
document.addEventListener("DOMContentLoaded", function () {
    const maxLength = 150;

    document.querySelectorAll(".info-description").forEach(function (elem) {
        const fullText = elem.dataset.full;
        if (fullText.length > maxLength) {
            const shortText = fullText.substring(0, maxLength) + "...";
            elem.innerText = shortText;

            const btn = elem.parentElement.querySelector(".toggle-deskripsi");
            btn.addEventListener("click", function () {
                if (btn.innerText === "Selengkapnya") {
                    elem.innerText = fullText;
                    btn.innerText = "Sembunyikan";
                } else {
                    elem.innerText = shortText;
                    btn.innerText = "Selengkapnya";
                }
            });
        } else {
            elem.innerText = fullText;
            const btn = elem.parentElement.querySelector(".toggle-deskripsi");
            btn.style.display = "none";
        }
    });
});
</script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ict-web\resources\views/admin/informasi.blade.php ENDPATH**/ ?>