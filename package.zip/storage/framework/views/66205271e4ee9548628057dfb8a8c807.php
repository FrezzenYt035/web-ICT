<a href="<?php echo e(route('dashboard')); ?>">
    <img src="<?php echo e(asset('img/logo_umtas.png')); ?>" style="height: 50px; width: auto;">
</a>
<?php /**PATH C:\xampp\htdocs\ict-web\resources\views/components/application-logo.blade.php ENDPATH**/ ?>