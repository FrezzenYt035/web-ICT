<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="img/logo_umtas.png">
    <title>Daftar Website</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .jojo {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }

        h2, h3 {
            color: #333;
            margin-bottom: 20px;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
            background-color: #fff;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.05);
        }

        .alert {
            padding: 10px 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
        }

        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
        }

        .btn-close {
            float: right;
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        th, td {
            padding: 12px 15px;
            border: 1px solid #ccc;
            text-align: left;
        }

        thead {
            background-color: #343a40;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .action-buttons {
            white-space: nowrap;
        }

        .btn {
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            margin-right: 5px;
            cursor: pointer;
        }

        .btn-warning {
            background-color: #ffc107;
            color: #000;
        }

        .btn-danger {
            background-color: #dc3545;
            color: #fff;
        }

        .btn-primary {
            background-color: #007bff;
            color: white;
            padding: 8px 16px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-label {
            display: block;
            margin-bottom: 6px;
            font-weight: bold;
        }

        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-section {
            margin-top: 30px;
            background-color: #f1f1f1;
            padding: 20px;
            border-radius: 10px;
        }
        @media (max-width: 768px) {
            .jojo {
                display: flex;
                flex-direction: column;
            }
            .yoyo {
                display: flex;
                flex-direction: column;
            }
            .wgi {
                display: flex;
                flex-direction: column;
            }
            .jned {
                display: flex;
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('daftar website')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
        <br>
        <br>
        <div class="container">
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" onclick="this.parentElement.style.display='none';">&times;</button>
                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <button type="button" class="btn-close" onclick="this.parentElement.style.display='none';">&times;</button>
                </div>
            <?php endif; ?>
            <div class="jojo">
                <table class="yoyo">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Website</th>
                        <th>URL</th>
                        <th>Type</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody class="wgi">
                    <?php $__currentLoopData = $websites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $website): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="jned">
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($website->name); ?></td>
                            <td><?php echo e($website->url); ?></td>
                            <td><?php echo e($website->type); ?></td>
                            <td class="action-buttons">
                                <a href="<?php echo e(route('admin.website.edit', ['id' => $website->id])); ?>">
                                    <button class="btn btn-warning">
                                        <i class="fas fa-edit"></i> Edit
                                    </button>
                                </a>
                                <form action="<?php echo e(route('admin.website.destroy', ['id' => $website->id])); ?>" method="post" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button class="btn btn-danger">
                                        <i class="fas fa-trash-alt"></i> Hapus
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <div class="form-section">
                <h3><?php echo e(isset($websitedetail) ? 'Edit Website' : 'Tambah Website Baru'); ?></h3>
                <form action="<?php echo e(isset($websitedetail) ? route('admin.website.update', ['id' => $websitedetail->id]) : route('admin.website.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php if(isset($websitedetail)): ?>
                        <?php echo method_field('put'); ?>
                    <?php endif; ?>

                    <div class="form-group">
                        <label for="name" class="form-label">Nama Website</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name', $websitedetail->name ?? '')); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="url" class="form-label">URL</label>
                        <input type="text" class="form-control" id="url" name="url" value="<?php echo e(old('url', $websitedetail->url ?? '')); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="type" class="form-label">Type</label>
                        <input type="text" class="form-control" id="type" name="type" value="<?php echo e(old('type', $websitedetail->type ?? '')); ?>" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    </div>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ict-web\resources\views/admin/website.blade.php ENDPATH**/ ?>